# Covid19-Fake-News-Detector

This project is built to detect covid19 related fake tweets.

In this project I have used the "Tweepy" API by Twitter to access their tweets from 01-06-2020 till 17-06-2020 all related to the current corona virus pandemic and have 
collected a total of 3068 tweets which were then manually hand labelled.

Upon text preprocessing tasks and data cleaning procedures I have hard coded Naive Bayes Classifer that gave an accuracy of 82 % which is implemented in Naive Bayes.ipynb.

I have also tried other classifier such as decision tree and Gaussian NB all of which can be found in Other Classifiers.ipynb.
